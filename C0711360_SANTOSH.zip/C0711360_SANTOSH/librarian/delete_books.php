<?php
ob_start();
    session_start();
    if (!isset($_SESSION['librarian'])) {
        ?>
        <script type="text/javascript">
            window.location="index.php";
        </script>

        <?php
    }
include "dbconnect.php";

if (isset($_GET['ID'])) {
	$id=$_GET['ID'];
mysqli_query($link, "DELETE FROM add_books WHERE ID=$id");
?>
<script type="text/javascript">
	window.location="display_books.php";
</script>
<?php

}else{ 
	?>
	<script type="text/javascript">
	window.location="display_books.php";
</script>
<?php	
}
