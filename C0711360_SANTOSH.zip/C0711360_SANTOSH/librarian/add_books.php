<?php
    ob_start();
    session_start();
    if (!isset($_SESSION['librarian'])) {
        ?>
        <script type="text/javascript">
            window.location="index.php";
        </script>

        <?php
    }
include "dbconnect.php";
include "header.php";

?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Home</title>
    </head>
    <body>
    <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Add Books Info</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                               <form name="form1" action="" method="POST" class="col-lg-6">
                                <table class="table table-bordered">
                                <tr>
                                    <td><input type="text" class="form-control" name="books_name" placeholder="Book Name" required=""/></td>
                                </tr>
                                <tr>
                                    <td>Book Image<input type="file" name="f1" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="text" class="form-control" name="book_author_name" placeholder="Book Author Name" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="text" class="form-control" name="books_publication_name" placeholder="Book Publication Name" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="text" class="form-control" name="books_purchase_date" placeholder="Purchase Date" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="text" class="form-control" name="books_price" placeholder="Book Price" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="text" class="form-control" name="books_qty" placeholder="Books Qty" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="text" class="form-control" name="avilablity_qty" placeholder="Avilablity Qty" required=""/></td>
                                </tr>

                                <tr>
                                    <td><input type="submit" class="btn btn-default submit" name="submit1" value="Add Book"></td>
                                </tr>
                                </table>
                                </form>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </body>
    </html>



<?php
error_reporting(E_PARSE);
    if (isset($_POST['submit1'])) {

        $tm=md5(time());
        $fnm = $_FILES['f1']['name'];
        $dst = "./books_image/".$tm.$fnm;
        $dst1 = "books_image/".$tm.$fnm;

        move_uploaded_file($_FILES['f1']['temp_name'], $dst);
        $bookname = mysqli_real_escape_string($link, $_REQUEST['books_name']);
        // $bookimg = mysqli_real_escape_string($link, $_REQUEST['books_img']);
        $bookauth = mysqli_real_escape_string($link, $_REQUEST['book_author_name']);
        $bookpub = mysqli_real_escape_string($link, $_REQUEST['books_publication_name']);
        $bookpurdate = mysqli_real_escape_string($link, $_REQUEST['books_purchase_date']);
        $bookprice = mysqli_real_escape_string($link, $_REQUEST['books_price']);
        $bookqty = mysqli_real_escape_string($link, $_REQUEST['books_qty']);
        $avilablityqty = mysqli_real_escape_string($link, $_REQUEST['avilablity_qty']);


// attempt insert query execution
$sql = "INSERT INTO add_books (books_name, books_img,books_author_name,books_publication_name,books_purchase_date,books_price,books_qty,avilablity_qty,librarian_username) VALUES ('$bookname','$dst1','$bookauth','$bookpub','$bookpurdate','$bookprice','$bookqty','$avilablityqty','$_SESSION[librarian]')";

if(mysqli_query($link, $sql)){
       ?>
<script type="text/javascript">
    alert("Book Added Succssfully");
</script>
       <?php
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
}
 
// close connection
mysqli_close($link);
?>

<?php
include "footer.php";
?>