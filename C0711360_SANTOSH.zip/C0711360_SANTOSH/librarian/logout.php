<?php
	ob_start();
    session_start();
    unset($_SESSION["librarian"]);
?>

<script type="text/javascript">
	window.location="index.php";
</script>