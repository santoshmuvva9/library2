.<?php
include "dbconnect.php";
$id= $_GET["ID"];
mysqli_query($link, "UPDATE user SET status='no' WHERE ID=$id");
?>

<script type="text/javascript">
	
	window.location="display_student_info.php"
</script>