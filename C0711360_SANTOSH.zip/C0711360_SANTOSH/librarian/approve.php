<?php
ob_start();
    session_start();
    if (!isset($_SESSION['librarian'])) {
        ?>
        <script type="text/javascript">
            window.location="index.php";
        </script>

        <?php
    }
include "dbconnect.php";
$id= $_GET["ID"];
mysqli_query($link, "UPDATE user SET status='yes' WHERE ID=$id");
?>

<script type="text/javascript">
	
	window.location="display_student_info.php"
</script>