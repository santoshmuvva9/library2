<?php
ob_start();
    session_start();
    if (!isset($_SESSION['librarian'])) {
        ?>
        <script type="text/javascript">
            window.location="index.php";
        </script>

        <?php
    }
include "dbconnect.php";
include "header.php";

?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Home</title>
    </head>
    <body>
    <!-- page content area main -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Plain Page</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
                <div class="row" style="min-height:500px">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Issue Book</h2>

                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <form name="form1" action="" method="POST">
                                    <table>
                                        <tr>
                                            <td>
                                                <select name="enr" class="form-control selectpicker">
                                                    <?php
                                                        $res = mysqli_query($link, "SELECT enrollment FROM user");
                                                        while ($row=mysqli_fetch_array($res)) {
                                                            echo "<option>";

                                                            echo $row["enrollment"];
                                                            echo "</option>";
                                                        }
                                                    ?>
                                                </select>
                                                
                                            </td>

                                            <td>
                                                <input type="submit" value="search" name="submit1" class="form-control btn btn-default">
                                            </td>
                                        </tr>
                                    </table>
                          
                                <?php

                                    if (isset($_POST["submit1"])) {
                                        $res=mysqli_query($link, "SELECT * FROM user WHERE enrollment='$_POST[enr]'");
                                        while ($row=mysqli_fetch_array($res))
                                         {
                                            $first_name=$row["first_name"];
                                            $last_name=$row["last_name"];
                                            $username=$row["username"];
                                            $email=$row["email"];
                                            $contact=$row["contact"];
                                            $sem=$row["sem"];
                                            $enrollment=$row["enrollment"];
                                            $_SESSION["enrollment"]= $enrollment;
                                            $_SESSION["susrename"]=$username;
                                        }
                                        ?>

                                <table class="table table-bordered">
                                <tr>
                                    <td><input type="text" class="form-control" name="enrollment" placeholder="Enrollment" value="<?php echo $enrollment;  ?>" disabled /></td>
                                     </tr>

                                      <tr>
                                    <td><input type="text" class="form-control" name="studentname" placeholder="Student Name" value="<?php echo $first_name.' '.$last_name; ?>" required /></td>
                                     </tr>

                                     <tr>
                                    <td><input type="text" class="form-control" name="studentsem" placeholder="Sem" value="<?php echo $sem;  ?> " required /></td>
                                     </tr>

                                     <tr>
                                    <td><input type="text" class="form-control" name="studentcontact" placeholder="Contact No" value="<?php echo $contact  ?>" required /></td>
                                     </tr>

                                     <tr>
                                    <td><input type="text" class="form-control" name="studentemail" placeholder="Email" value="<?php echo $email ?>" required /></td>
                                     </tr>

                                     <td>
                                         <select name="bookname" class="form-control selectpicker">
                                             <?php
                                             $res=mysqli_query($link, "SELECT books_name FROM add_books");
                                             while ($row=mysqli_fetch_array($res)) {
                                                 echo "<option>";

                                                 echo $row["books_name"];
                                                 echo "</option>";
                                             }
                                             ?>

                                         </select>
                                     </td>
                                 </tr>

                                    <tr>
                                        <td>
                                            <input type="text" class="form-control" name="booksissuedate" placeholder="Book Issued Date" value="<?php echo date("d-M-Y");  ?>" required />
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <input type="text" class="form-control" name="studentusername" placeholder="Student UserName" value="<?php echo $username;  ?>" disabled />
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <input type="submit" class="form-control btn btn-default" name="submit2" value="Issued Book" />
                                        </td>
                                    </tr>
                                </table>
                                    <?php
                                    }
                                    ?>
                                </form>
                                <?php
                                if (isset($_POST['submit2'])) {

                                    $qty=0;
                                    $res=mysqli_query($link, "SELECT * FROM add_books WHERE books_name='$_POST[bookname]'");
                                    while ($row=mysqli_fetch_array($res)) {
                                        $qty=$row["avilablity_qty"];
                                    }

                                    if($qty==0)
                                    {
                                        ?>
                                        <div class="alert alert-danger col-lg-6 col-lg-push-3">
                                            <strong style="color:white">Book Not in Stock</strong>.
                                        </div>

                                        <?php
                                    }else{


                                            $enrollment=$_POST["enrollment"];
                                            $studentname=$_POST["studentname"];
                                            $studentsem=$_POST["studentsem"];
                                            $studentcontact=$_POST["studentcontact"];
                                            $studentemail=$_POST["studentemail"];
                                            $bookname=$_POST["bookname"];
                                            $booksissuedate=$_POST["booksissuedate"];
                                            $username=$_POST["studentusername"];


                                    mysqli_query($link, "INSERT INTO issue_books (student_enrollment,student_name,student_sem,student_contact,student_email,books_name,books_issued_date,books_return_date,student_username)VALUES ('$_SESSION[enrollment]','$studentname','$studentsem','$studentcontact','$studentemail','$bookname','$booksissuedate','','$_SESSION[susername]')");
                                    mysqli_query($link, "UPDATE add_books SET avilablity_qty=avilablity_qty-1 WHERE books_name='$bookname'");

                                    ?>
                                        <script type="text/javascript">
                                            
                                            alert("Book Saved Successfully");
                                            window.location.href=window.location.href;
                                        </script>


                                    <?php
                                }
                             }
                                ?>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

    </body>
    </html>    
<?php
include "footer.php";
?>