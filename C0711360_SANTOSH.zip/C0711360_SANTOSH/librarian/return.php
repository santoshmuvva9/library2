<?php
include "dbconnect.php";

$id=$_GET["ID"];
$a=date("d-M-Y");
$res=mysqli_query($link, "UPDATE issue_books SET books_return_date='$a' WHERE ID=$id");
$books_name="";
$res=mysqli_query($link, "SELECT * FROM issue_books WHERE ID=$id");
while ($row=mysqli_fetch_array($res)) {
	$books_name=$row["books_name"];
}

 mysqli_query($link, "UPDATE add_books SET avilablity_qty=avilablity_qty+1 WHERE books_name='$books_name'");
?>

<script type="text/javascript">
	window.location="return_book.php";
</script>